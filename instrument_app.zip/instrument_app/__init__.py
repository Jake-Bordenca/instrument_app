"""Top-level package for instrument_app."""
__all__ = ["__version__"]
__version__ = "0.1.0"  # bump when you release
