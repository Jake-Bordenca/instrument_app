
BAUD_RATE = 115200
READ_PERIOD_MS = 1000          # polling cadence (1 Hz)
CSV_BASENAME = "vacuum_log"    # final name gets timestamp suffix
